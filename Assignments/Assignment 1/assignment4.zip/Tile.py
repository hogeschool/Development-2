﻿import pygame
import random
import os


class Cons:
    def __init__(self, value, tail):
        self.Tail = tail
        self.Value = value
        self.IsEmpty = False


class Empty:
    def __init__(self):
        self.IsEmpty = True


Empty = Empty()
NotTraversable = 0


class Node:
    def __init__(self, position, texture, offset, properties):
        self.Properties = properties
        self.Up = None
        self.Down = None
        self.Left = None
        self.Right = None
        self.Value = Empty
        self.Properties = Empty
        self.Position = position
        self.DefaultTexture = pygame.image.load(texture).convert()
        self.Visited = False
        self.Offset = offset
        props = properties

        traversable = True
        while not props.IsEmpty:
            if props.Value == NotTraversable:
                traversable = False
            props = props.Tail

        self.Traversable = traversable

    def Reset(self):
        if self.Visited:
            self.Visited = False
            if self.Up is not None:
                self.Up.Reset()
            if self.Down is not None:
                self.Down.Reset()
            if self.Left is not None:
                self.Left.Reset()
            if self.Right is not None:
                self.Right.Reset()

    def Update(self):
        Exception("Not implemented yet")

    def Draw(self, screen):
        if not self.Visited:
            self.Visited = True
            if self.Traversable:
                _width = int(self.Offset / 3)
                dim = 2
                screen.blit(pygame.transform.scale(self.DefaultTexture, (_width + dim, _width + dim)),
                            (_width + self.Position[0] * self.Offset,
                             _width + self.Position[1] * self.Offset))

                if self.Up is not None and self.Up.Traversable:
                    screen.blit(pygame.transform.scale(self.DefaultTexture, (_width + dim, _width + dim)),
                                (_width + self.Position[0] * self.Offset,
                                 self.Position[1] * self.Offset))
                if self.Down is not None and self.Down.Traversable:
                    screen.blit(pygame.transform.scale(self.DefaultTexture, (_width + dim, _width + dim)),
                                (_width + self.Position[0] * self.Offset,
                                 _width * 2 + self.Position[1] * self.Offset))
                if self.Left is not None and self.Left.Traversable:
                    screen.blit(pygame.transform.scale(self.DefaultTexture, (_width + dim, _width + dim)),
                                (self.Position[0] * self.Offset,
                                 _width + self.Position[1] * self.Offset))
                if self.Right is not None and self.Right.Traversable:
                    screen.blit(pygame.transform.scale(self.DefaultTexture, (_width + dim, _width + dim)),
                                (_width * 2 + self.Position[0] * self.Offset,
                                 _width + self.Position[1] * self.Offset))
            else:
                screen.blit(pygame.transform.scale(self.DefaultTexture, (self.Offset - 1, self.Offset - 1)),
                            (self.Position[0] * self.Offset, self.Position[1] * self.Offset))

            if self.Up is not None:
                self.Up.Draw(screen)
            if self.Down is not None:
                self.Down.Draw(screen)
            if self.Left is not None:
                self.Left.Draw(screen)
            if self.Right is not None:
                self.Right.Draw(screen)


def build_square_matrix(dimension, offset):
    entry_point = None
    above_line = None
    prev_node = None
    for row in range(dimension):
        for column in range(dimension):
            if random.uniform(0, 1) > 0.8:
                properties = Cons(NotTraversable, Empty)
                node = Node((column, row), os.path.join("Content", "house.png"), offset, properties)
            else:
                node = Node((column, row), os.path.join("Content", "white_pixel.png"), offset, Empty)

            if row == 0 and column == 0:
                entry_point = node
            if column == 0:
                prev_node = node
            else:
                prev_node.Right = node
                node.Left = prev_node
                prev_node = node
            if row > 0:
                node.Up = above_line
                above_line.Down = node
                above_line = above_line.Right

        while prev_node.Left is not None:
            prev_node = prev_node.Left
        above_line = prev_node
    return entry_point
