﻿import random
from Node import *
from Common import *

#BOAT CODE HERE

#NOTE: TO DRAW USE THE CODE AS IN ASSIGNMENT 1