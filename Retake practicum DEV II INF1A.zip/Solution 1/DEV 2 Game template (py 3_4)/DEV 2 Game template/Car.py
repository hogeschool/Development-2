﻿import pygame
from Node import *

class Car:
  def __init__(self, tile):
    self.Tile = tile
